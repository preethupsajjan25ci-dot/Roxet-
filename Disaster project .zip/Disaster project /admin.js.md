const db = firebase.firestore();  
  
// USERS  
db.collection("users").get().then(data => {  
  data.forEach(doc => {  
    users.innerHTML += `<li>${doc.data().name} - Age ${doc.data().age}</li>`;  
  });  
});  
  
// ALERTS  
db.collection("alerts").get().then(data => {  
  data.forEach(doc => {  
    alerts.innerHTML += `<li>${doc.data().message}</li>`;  
  });  
});  
