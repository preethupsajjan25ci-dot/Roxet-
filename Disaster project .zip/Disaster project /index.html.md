<!DOCTYPE html>  
<html>  
<head>  
  <title>Disaster Management System</title>  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  
  
  <!-- Firebase -->  
  <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-app-compat.js"></script>  
  <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore-compat.js"></script>  
  
  <link rel="stylesheet" href="style.css">  
</head>  
  
<body>  
  
<h1>🌍 Disaster Preparedness System</h1>  
  
<!-- REGISTER -->  
<div class="box">  
  <h2>Register</h2>  
  <input id="name" placeholder="Name"><br>  
  <input id="age" type="number" placeholder="Age"><br>  
  <input id="email" placeholder="Email"><br>  
  <input id="password" type="password" placeholder="Password"><br>  
  
  <div id="guardianBox" style="display:none;">  
    <h3>Guardian Details</h3>  
    <input id="gname" placeholder="Guardian Name"><br>  
    <input id="gphone" placeholder="Guardian Phone"><br>  
    <input id="gemail" placeholder="Guardian Email"><br>  
  </div>  
  
  <button onclick="register()">Register</button>  
</div>  
  
<!-- SOS -->  
<div class="box">  
  <h2>🆘 SOS</h2>  
  <button onclick="sendSOS()">Send Emergency Alert</button>  
</div>  
  
<!-- CHATBOT -->  
<div class="box">  
  <h2>🤖 AI Assistant</h2>  
  <input id="userInput" placeholder="What is happening?">  
  <button onclick="askAI()">Ask</button>  
  <p id="response"></p>  
</div>  
  
<!-- VISUAL LEARNING -->  
<div class="box">  
  <h2>🎨 Visual Learning</h2>  
  <div class="card"><img src="images/earthquake.png"><p>Drop, Cover, Hold</p></div>  
  <div class="card"><img src="images/flood.png"><p>Go to higher ground</p></div>  
  <div class="card"><img src="images/fire.png"><p>Stay low, exit</p></div>  
  <div class="card"><img src="images/cyclone.png"><p>Stay indoors</p></div>  
</div>  
  
<!-- QUIZ -->  
<div class="box">  
  <h2>🧪 Quiz</h2>  
  <p>What should you do during an earthquake?</p>  
  <button onclick="checkAnswer('a')">Run outside</button>  
  <button onclick="checkAnswer('b')">Hide under table</button>  
  <p id="quizResult"></p>  
</div>  
  
<!-- MAP -->  
<div class="box">  
  <h2>📍 Nearby Hospitals</h2>  
  <iframe src="https://www.google.com/maps?q=hospital&output=embed"></iframe>  
</div>  
  
<script src="script.js"></script>  
  
</body>  
</html>  
