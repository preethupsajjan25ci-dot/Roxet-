// 🔥 Firebase config  
const firebaseConfig = {  
  apiKey: "YOUR_KEY",  
  authDomain: "YOUR_DOMAIN",  
  projectId: "YOUR_ID"  
};  
  
firebase.initializeApp(firebaseConfig);  
const db = firebase.firestore();  
  
// Show guardian if minor  
document.getElementById("age").addEventListener("input", function () {  
  document.getElementById("guardianBox").style.display =  
    this.value < 18 ? "block" : "none";  
});  
  
// REGISTER  
function register() {  
  const age = age.value;  
  
  db.collection("users").add({  
    name: name.value,  
    age: age,  
    email: email.value,  
    guardian: age < 18 ? {  
      name: gname.value,  
      phone: gphone.value,  
      email: gemail.value  
    } : null  
  });  
  
  alert("Registered successfully!");  
}  
  
// SOS  
function sendSOS() {  
  navigator.geolocation.getCurrentPosition(pos => {  
    const lat = pos.coords.latitude;  
    const lon = pos.coords.longitude;  
  
    const location = `https://maps.google.com/?q=${lat},${lon}`;  
  
    db.collection("alerts").add({  
      message: location,  
      time: new Date()  
    });  
  
    window.open(`sms:?body=Emergency! My location: ${location}`);  
  });  
}  
  
// QUIZ  
function checkAnswer(ans) {  
  document.getElementById("quizResult").innerText =  
    ans === 'b' ? "Correct!" : "Wrong!";  
}  
  
// AI CHATBOT  
async function askAI() {  
  const input = document.getElementById("userInput").value;  
  
  const res = await fetch("https://api.openai.com/v1/chat/completions", {  
    method: "POST",  
    headers: {  
      "Authorization": "Bearer YOUR_API_KEY",  
      "Content-Type": "application/json"  
    },  
    body: JSON.stringify({  
      model: "gpt-4o-mini",  
      messages: [  
        {  
          role: "system",  
          content: "You are a calm disaster assistant. Ask what is happening and give simple safety tips."  
        },  
        {  
          role: "user",  
          content: input  
        }  
      ]  
    })  
  });  
  
  const data = await res.json();  
  document.getElementById("response").innerText =  
    data.choices[0].message.content;  
}  
