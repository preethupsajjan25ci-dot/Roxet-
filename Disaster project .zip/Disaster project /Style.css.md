body {  
  font-family: Arial;  
  text-align: center;  
  background: linear-gradient(to right, #dfe9f3, #ffffff);  
}  
  
h1 {  
  color: #2c3e50;  
}  
  
.box {  
  background: white;  
  margin: 20px;  
  padding: 15px;  
  border-radius: 10px;  
}  
  
input {  
  padding: 8px;  
  margin: 5px;  
}  
  
button {  
  padding: 10px;  
  margin: 5px;  
  background: #e74c3c;  
  color: white;  
  border: none;  
  border-radius: 5px;  
}  
  
.card {  
  display: inline-block;  
  width: 120px;  
  margin: 10px;  
}  
  
.card img {  
  width: 100%;  
  border-radius: 10px;  
}  
  
iframe {  
  width: 100%;  
  height: 250px;  
}  
