<!DOCTYPE html>  
<html>  
<head>  
  <title>Admin Dashboard</title>  
</head>  
<body>  
  
<h1>📊 Admin Dashboard</h1>  
  
<h2>Users</h2>  
<ul id="users"></ul>  
  
<h2>Alerts</h2>  
<ul id="alerts"></ul>  
  
<script src="admin.js"></script>  
  
</body>  
</html>  
